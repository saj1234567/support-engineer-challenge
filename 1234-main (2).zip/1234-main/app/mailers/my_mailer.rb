class MyMailer < ApplicationMailer
    def send_email
      mail(to: 'sajawalk21@gmail.com', subject: 'Test email') do |format|
        format.text { render plain: 'This is a test email!' }
      end
    end
end