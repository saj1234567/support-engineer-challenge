class RootController < ApplicationController
  def create
  end
end
